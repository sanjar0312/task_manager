CREATE TABLE IF NOT EXISTS public.tasks
(
    id serial NOT NULL,
    type character varying NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    date date NOT NULL,
    PRIMARY KEY (id)
);