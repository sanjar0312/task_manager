package com.usenovsanjar.task_manager.dto;

import com.usenovsanjar.task_manager.entity.TaskType;
import lombok.Data;

@Data
public class TaskDTO {
    TaskType type;
    String title;
    String description;
    String date;
}
