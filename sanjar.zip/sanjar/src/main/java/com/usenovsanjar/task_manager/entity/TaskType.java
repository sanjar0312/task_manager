package com.usenovsanjar.task_manager.entity;

public enum  TaskType {
    URGENT, ORDINARY, WORK, SHOPPING
}
