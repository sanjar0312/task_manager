package com.usenovsanjar.task_manager.dto;

import com.usenovsanjar.task_manager.entity.TaskType;
import lombok.Data;

@Data
public class UpdateTaskDTO {
    Integer id;
    String title;
    String description;
    TaskType type;
    String date;
}
